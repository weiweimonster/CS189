Jacob Hsiung 
SID:3036180978

There are no external libraries that needs to be installed, and the random seed is set to a fix number at the beggining. The Decision Tree class is implemented, and Random Forest is implemented as the child of Decision Tree. If you wish to duplicate the results I have, please uncommented out the corresponding portion in the bottom of the code. I've labeled the code section related to each subpart of the question.