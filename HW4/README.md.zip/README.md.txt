Student Name: Jacob Hsiung
Student ID: 3036180978
Kaggle Score: 0.98792

The random seed was set to 1130 in the beggining of my code. I created a class for each coding question. But all the code to reproduce my results were commented out in the main function. To reproduce my result, you can simply uncomment the desired portion and run the code.