Student ID:3036180978
Random Seed: 4963
For plots of iscocontours please refer to "Isocontours_of_Normal_Distribution.py". I've labeled the portion of code corresponding to each subpart of the problem. If you uncommented the portion and run, you can get the exact same plot.
For plots of Eigenvectors please refer to "EigenCevtors.py". I've labeled the corresponding code to each part of the problem. The random seed is set to 4963. If you run the entire script you can reproduce the the same output.
For Question 8, part 1 and 2 are in "CS189HW3Q8.py". If you run the script you can get the visualization of the mean and covariance matrix of class 3.
For problem 8, the rest of the code are in "LDA_QDA.py". Each function represent different part of the problem. The run_model() function will produce the plot of LDA or QDA error vs training points based the argument passed in. The error_of_each_class() function will plot the classification error digitwise for either LDA or QDA depending on the argument passed in. The mnist_test_prediction() and spam_test_prediction produce the submission.csv file for kaggle competition.
If you uncommented out the desired part and run, you should get the same result.

Thank you