# CS189/289A HW6: Neural Networks

Before running the code in this directory, please create a new `conda`
environment by running:
```sh
bash conda_create.sh
conda activate cs189sp22
```

To run all the tests, please run:
```sh
python -m unittest -v
```

Before submitting, please make sure that all the tests pass.



Studend ID: 3036180978
Student Name: Jacob Hsiung
Kaggle username: weiweimonster

